let img;

function preload() {
  img = loadImage('imagem.jpg'); // Substitua 'imagem.png' pelo nome do seu arquivo
}

function setup() {
  createCanvas(1000, 900);
}

function draw() {
  background(220); // Define um fundo
  image(img, 0, 0, 900, 800); // Desenha a imagem a partir da posição (50, 50) com tamanho 200x200
}

let xJogador1 = 0;
let xJogador2 = 0;
let xjogador3 = 50;
function draw() {
  background(img)
  textSize(100);
  text("🚁", xJogador1, 150);
  text("💧", xJogador1, 280);
  text("💧", xJogador1, 400);
  text("💧", xJogador1, 520);
  xJogador1 += random(5);
  xJogador2 += random(0);
  xjogador3 += random(0);
}